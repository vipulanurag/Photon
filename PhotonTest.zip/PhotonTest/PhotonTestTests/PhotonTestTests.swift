//
//  PhotonTestTests.swift
//  PhotonTestTests
//
//  Created by Manish on 2/16/17.
//  Copyright © 2017 Anurag. All rights reserved.
//

import XCTest
@testable import PhotonTest

class PhotonTestTests: XCTestCase {
    
    var outputArray = [Int](), outPutSum = 0
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
    func testTransposition() {
        
        let matrix = Matrix<Any>.init(rows: 5, cols: 6, filler: 0)
        matrix[0,0] = 3; matrix[0,1] = 4; matrix[0,2] = 1; matrix[0,3] = 2; matrix[0,4] = 8; matrix[0,5] = 6;
        matrix[1,0] = 6; matrix[1,1] = 1; matrix[1,2] = 8; matrix[1,3] = 2; matrix[1,4] = 7; matrix[1,5] = 4;
        matrix[2,0] = 5; matrix[2,1] = 9; matrix[2,2] = 3; matrix[2,3] = 9; matrix[2,4] = 9; matrix[2,5] = 5;
        matrix[3,0] = 8; matrix[3,1] = 4; matrix[3,2] = 1; matrix[3,3] = 3; matrix[3,4] = 2; matrix[3,5] = 6;
        matrix[4,0] = 3; matrix[4,1] = 7; matrix[4,2] = 2; matrix[4,3] = 8; matrix[4,4] = 6; matrix[4,5] = 4;
        
        XCTAssertTrue(matrix.rowCount()>0)
        XCTAssertTrue(matrix.colCount()>0)
    }
    
}
