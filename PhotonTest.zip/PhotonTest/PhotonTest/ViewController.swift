//
//  ViewController.swift
//  PhotonTest
//
//  Created by Anurag on 2/16/17.
//  Copyright © 2017 Anurag. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    public var outputArray = [Int](), outPutSum = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

        var x = 0
        let m = 5, n = 6
        
        //Creating a 2d Array/Matrix
        let matrix = Matrix<Any>.init(rows: m, cols: n, filler: 0)
        matrix[0,0] = 3; matrix[0,1] = 4; matrix[0,2] = 1; matrix[0,3] = 2; matrix[0,4] = 8; matrix[0,5] = 6;
        matrix[1,0] = 6; matrix[1,1] = 1; matrix[1,2] = 8; matrix[1,3] = 2; matrix[1,4] = 7; matrix[1,5] = 4;
        matrix[2,0] = 5; matrix[2,1] = 9; matrix[2,2] = 3; matrix[2,3] = 9; matrix[2,4] = 9; matrix[2,5] = 5;
        matrix[3,0] = 8; matrix[3,1] = 4; matrix[3,2] = 1; matrix[3,3] = 3; matrix[3,4] = 2; matrix[3,5] = 6;
        matrix[4,0] = 3; matrix[4,1] = 7; matrix[4,2] = 2; matrix[4,3] = 8; matrix[4,4] = 6; matrix[4,5] = 4;
        
        //Initializing a 2d array to get the rotated original Matrix
        let newMatrix = Matrix<Any>.init(rows: n, cols: m, filler: 0)

        for i in 0 ..< n  {
            for j in 0 ..< m{
                newMatrix[i,x] = matrix[j,i]
                print(newMatrix[i,x])
                x = x+1
            }
            x = 0
        }
        
        for i in 0 ..< n  {
            let rowArray = newMatrix.getRow(rowIndex: i)
            let smallestNumberIndex = self.getSmallestNumber(rowArray: rowArray as! [Int])
            outputArray.append(smallestNumberIndex)
            outPutSum = newMatrix[i,smallestNumberIndex] as! Int
        }
        
        //Desired result
        print(outputArray.count == n)
        print(outputArray)
        print(outPutSum)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func getSmallestNumber(rowArray : [Int]) -> Int {
        
        var i = 0, minNumIndex = 0
        var small = rowArray[0]
        while i < rowArray.count{
            if (rowArray[i] < small) {
                small = rowArray[i]
                minNumIndex = i
            }
            i = i + 1
        }
        return minNumIndex
    }
}

