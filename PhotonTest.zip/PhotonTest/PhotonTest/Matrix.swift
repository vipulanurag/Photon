//
//  Matrix.swift
//  PhotonTest
//
//  Created by Anurag on 2/16/17.
//  Copyright © 2017 Anurag. All rights reserved.
//

import Foundation

class Matrix<T>
{
    var cols:Int, rows:Int
    var matrix:[T]
    
    init(rows:Int, cols:Int, filler:T) {
        self.cols = cols
        self.rows = rows
        matrix = Array<T>(repeating:filler, count:cols*rows)
    }
    
    subscript(row:Int, col:Int) -> T {
        get
        {
            return matrix[cols * row + col]
        }
        set
        {
            matrix[cols * row + col] = newValue
        }
    }
    
    func getRow(rowIndex:Int) -> [T]
    {
        var row = [T]()
        for colIndex in 0..<cols
        {
            row.append(matrix[cols*rowIndex + colIndex])
        }
        
        return row
    }
    
    func getCol(colIndex:Int) -> [T]
    {
        var col = [T]()
        for rowIndex in 0..<rows
        {
            col.append(matrix[cols*rowIndex + colIndex])
        }
        
        return col
    }
    
    func toVector() -> [T]
    {
        return matrix
    }
    
    func colCount() -> Int {
        return self.cols
    }
    
    func rowCount() -> Int {
        return self.rows
    }
}
